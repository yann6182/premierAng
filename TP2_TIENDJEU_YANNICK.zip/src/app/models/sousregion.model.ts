import { Region } from './region.model';

export interface SousRegion {
    name: string;
    region: Region;
  }